<?php get_header();?>

<div id="content" class="grid_10">
<?php 

	//echo category_description( $category );
	
	if(get_option('swift_archives_magzine')=="magzine")
		magloop(0);
	else
		blogloop(get_option('swift_archive_excerpts_enable'),get_option('swift_thumbs_disable'),0);
?>
</div><!--/content-->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
