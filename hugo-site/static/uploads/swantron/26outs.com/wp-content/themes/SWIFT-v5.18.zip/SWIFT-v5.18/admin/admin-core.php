<?php
add_action('admin_menu', 'swift_headers1');
add_action('admin_head', 'swift_headers2');
?>
<?php
function swift_headers1(){
	if ( $_GET['page'] == "swift-options"||$_GET['page'] == "swift-design-options" ){
		wp_enqueue_script('jquery' ); 
		wp_enqueue_script('jquery-ui-core');
		wp_enqueue_script('jquery-ui-tabs');
		wp_enqueue_script('jquery-ui-sortable');
	}
}
?>
<?php 
function swift_headers2(){ 
if ( $_GET['page'] == "swift-options"||$_GET['page'] == "swift-design-options" ):
?>
<script type="text/javascript">
	jQuery(function() {
	jQuery(".tabmenu").removeClass("hidden");
	jQuery(".tabs h2").addClass("hidden");
	jQuery(".tabs").tabs();
	});
</script> 
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url')?>/admin/admin-styles.css" media="screen" />	
<?php endif;
if ($_GET['page'] == "swift-design-options" ):
?>
	<script language="javascript" type="text/javascript" src="<?php bloginfo('template_url')?>/admin/jscolor/jscolor.js"></script> 
<?php endif; 
}//end of fucntion ?>
<?php
add_action('admin_menu', 'swift_themes_menu');

function swift_themes_menu() {
add_menu_page('Swift Theme Options', 'Swift Options', '10', 'swift-options', 'swiftOptions','http://swiftthemes.com/blog/wp-content/themes/swift-v4.1.5/images/favicon.ico',62);
add_submenu_page( 'swift-options', 'Design Options', 'Design Options', '10', 'swift-design-options', 'swiftDesignOptions');
}

function swiftOptions() {
 include(ADMIN.'/swift-options.php');
}
function swiftDesignOptions() {
 include(ADMIN.'/swift-design-options.php');
}

function resetSwiftOptions(){
	if( 'Reset' == $_POST['general-reset'] || 'Reset' == $_POST['design-reset'] ) {
	global $swift_design_options;
	global $swift_options;
	if('Reset' == $_POST['general-reset']) $options=$swift_options;
	else  $options=$swift_design_options;
            foreach ($options as $value) {
 				delete_option($value['id']);
				update_option($value['id'],$value['std']);	 
				}
				create_style_sheet();
			}
}

function first_run_options() {

  if ( get_option('swift_activation_check')!="set" ) {
    // DO INITIALISATION STUFF
	//if (!is_dir(U_DIR)) $make = @mkdir(U_DIR,0777);
	
	$filename = U_DIR.'/swift_default.jpg';
		if (!file_exists($filename)):
			$file = TEMPLATEPATH.'/images/default.jpg';
			copy($file, $filename);
		endif;
		
		//Creates the timthumb cache folder
		$swift_custom=U_DIR.'/swift_custom';
		$cache= $swift_custom.'/cache';
		if (!is_dir($swift_custom)) $make = @mkdir($swift_custom,0777);
		if (!is_dir($cache)) $make = @mkdir($cache,0777);
		
		
		//Copy the timthumb.php script
		$final=U_DIR. '/swift_custom/timthumb.php';//timthumb.php will be copied to uploads/swift-custom
		$fp=fopen($final,'w');
		$base=TEMPLATEPATH.'/includes/timthumb.php';
		$fh0=fopen($base,'r');	
		$data.= fread($fh0, filesize($base));
		fwrite($fp,$data);
		
		//Copy the custom-style.css
		$final_style=U_DIR. '/swift_custom/custom-style.css';
		$fp1=fopen($final_style,'w');
		$base_style=TEMPLATEPATH.'/includes/custom-style.css';
		$fh1=fopen($base_style,'r');	
		$data2.= fread($fh1, filesize($base_style));
		fwrite($fp1,$data2);
		
    // Add marker so it doesn't run in future
    update_option('swift_activation_check', "set");
  }
  
  if(!get_option('swift_random')){
	global $swift_design_options;
	global $swift_options;	
	foreach ($swift_options as $value) {
 				delete_option($value['id']);
				update_option($value['id'],$value['std']);	 
				}
	foreach ($swift_design_options as $value) {
 				delete_option($value['id']);
				update_option($value['id'],$value['std']);	 
				}
	 }
}


function delete_stuff() {
  delete_option('swift_activation_check');
} 
?>
