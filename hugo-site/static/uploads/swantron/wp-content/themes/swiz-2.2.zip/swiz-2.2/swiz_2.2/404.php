<?php get_header(); ?>
<div id="content" class="error grid_10">


<h2 class="archive-title">404 FTL</h2>
<p style="font-size:1.3em; line-height:1.8em">
You've done it now.<br/>

Not sure what "it" was, but you managed to do it.  <br/>

If it happens again, shoot me a line...joe at swantron dot com.  Sorry, and thanks.<br />
</p>
<?php include(INCLUDES .'/archive-listing.php');?>
</div><!--/content-->
<?php get_sidebar(); ?>
<?php get_footer(); ?>
