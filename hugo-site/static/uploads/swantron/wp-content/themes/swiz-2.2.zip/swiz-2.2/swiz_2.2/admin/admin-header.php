<?php function admin_header(){?>


<div class="swiz-wrapper" class="wrap clearfix">


<div id="swiz-header" class="clearfix">

	<div id="swiz-logo" class="alignleft">
	<a href="http://swantron.com" rel="external" ><img src="<?php bloginfo('template_url')?>/admin/images/swiz-logo.png" /></a>
	</div>

    
</div>	
    
	<div id="nav">
    	<ul style="float:left;border-bottom:none">
        <li style="padding:.2em 1em; border:none" >Using Swiz2.2</li>
        </ul>
    	<ul class="clearfix">
    		<li><a href="http://swantron.com" title="swantron home">swantron dot com</a></li>
			<li><a href="http://swantron.com/contact" title="contact author">contanct author</a></li>
    	</ul>
	</div><!--/nav1-->
<div class="clear"></div>
<?php }?>
