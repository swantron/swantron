<div style="float:right; display:inline; padding-top:10px" class="grid_5 omega">
<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('sr') )?></div>
</div>