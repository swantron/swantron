<div id="sb-container" style="padding-top:10px"class="grid_5 alpha">
<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('sl') )?></div>
</div>