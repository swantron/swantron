<?php

// Directory constants
define('INCLUDES', TEMPLATEPATH . '/includes');
define('ADMIN', TEMPLATEPATH . '/admin');
define('WIDGETS', TEMPLATEPATH . '/widgets');
define('FUNCTIONS', TEMPLATEPATH . '/functions');
define('LAYOUTS', TEMPLATEPATH . '/layouts');



require_once (INCLUDES . '/sidebar-init.php'); // Initializes the sidebars
require_once (INCLUDES . '/navigation.php');
require_once (INCLUDES . '/thumb.php');

require_once (ADMIN. '/admin-core.php');
require_once (ADMIN. '/admin-header.php');
require_once (ADMIN. '/theme-options-init.php');
require_once (ADMIN. '/swift-color-options-init.php');
require_once (ADMIN. '/pageorder.php');
require_once (ADMIN. '/categoryorder.php');
require_once (ADMIN. '/create-styles.php');

require_once (FUNCTIONS. '/custom-functions.php');

require_once (LAYOUTS. '/blog-loop.php');
require_once (LAYOUTS. '/mag-loop.php');

require_once (WIDGETS . '/widget-functions.php');
require_once (WIDGETS . '/widgets.php'); 

add_action('widgets_init', create_function('', 'return register_widget("swiftTabs");'));
add_action('widgets_init', create_function('', 'return register_widget("swiftPopularPosts");')); 
add_action('widgets_init', create_function('', 'return register_widget("swiftAdsWidget");')); 
add_action('widgets_init', create_function('', 'return register_widget("SubscribeBox");')); 
 

add_action('update_option', 'create_style_sheet');
add_action('update_option', 'resetSwiftOptions');


add_action('admin_head', 'first_run_options');



add_action('switch_theme', 'delete_stuff');




?>