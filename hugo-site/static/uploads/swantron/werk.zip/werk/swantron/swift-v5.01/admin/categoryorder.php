<?php

//add_filter( 'plugin_row_meta', 'mycategoryorder_set_plugin_meta', 10, 2 );

add_filter('get_terms_orderby', 'swift_mycategoryorder_applyorderfilter', 10, 2);
 function mycategoryorder_getTarget() {
	return "admin.php";
}

function swift_mycategoryorder()
{wp_enqueue_script('jquery');
		wp_enqueue_script('jquery-ui-core');
		wp_enqueue_script('jquery-ui-sortable');
	global $wpdb;
	
	$mode = "";
	$mode = $_GET['mode'];
	$parentID = 0;
	$success = "";
	if (isset($_GET['parentID']))
	    $parentID = $_GET['parentID'];
		
	if(isset($_GET['hideNote']))
		update_option('mycategoryorder_hideNote', '1');
		
	$wpdb->show_errors();

	$query1 = $wpdb->query("SHOW COLUMNS FROM $wpdb->terms LIKE 'term_order'");
	
	if ($query1 == 0) {
		$wpdb->query("ALTER TABLE $wpdb->terms ADD `term_order` INT( 4 ) NULL DEFAULT '0'");
	}

	if($mode == "act_OrderCategories")
	{  
		$idString = $_GET['idString'];
		$catIDs = explode(",", $idString);
		$result = count($catIDs);
		
		$catString=$_GET['catString'];
		
		for($i = 0; $i < $result; $i++)
		{	
			$wpdb->query("UPDATE $wpdb->terms SET term_order = '$i' WHERE term_id ='$catIDs[$i]'");
		}
		$success = '<div id="message" class="updated fade"><p>'. __('Categories updated successfully.', 'mycategoryorder').'</p></div>';
		update_option( 'swift_cat_inc', $catString );

	}

	$subCatStr = "";

	$results=$wpdb->get_results("SELECT t.term_id, t.name FROM $wpdb->term_taxonomy tt, $wpdb->terms t, $wpdb->term_taxonomy tt2 WHERE tt.parent = $parentID AND tt.taxonomy = 'category' AND t.term_id = tt.term_id AND tt2.parent = tt.term_id GROUP BY t.term_id, t.name HAVING COUNT(*) > 0 ORDER BY t.term_order ASC");
	foreach($results as $row)
	{
		$subCatStr = $subCatStr."<option value='$row->term_id'>$row->name</option>";
	}
?>

	
<?php 
	if($parentID != 0)
	{
		$parentsParent = $wpdb->get_row("SELECT parent FROM $wpdb->term_taxonomy WHERE term_id = $parentID ", ARRAY_N);
		echo "<a href='". mycategoryorder_getTarget() . "?page=mycategoryorder&parentID=$parentsParent[0]'>".__('Return to parent category','mycategoryorder')."</a>";
	}

	 
 
	$results=$wpdb->get_results("SELECT * FROM $wpdb->terms t inner join $wpdb->term_taxonomy tt on t.term_id = tt.term_id WHERE taxonomy = 'category'  ORDER BY term_order ASC"); ?>
<div id="cat-order" >
	<h3><?php _e('Order Categories','mycategoryorder'); ?></h3>
    <p>Start by selecting the categories you want to include in your nav menu. Next, drag and drop thecategories to change their display order (topmost item displays first), click the order categories button below to save.</p>
	<ul id="orderCats">
    
		<?php 
			$inc=explode(',',get_option('swift_cat_inc'));
			
		foreach($results as $row)
		{
		if (in_array($row->term_id, $inc))$check='"checked"'; 
		else  $check="";
			echo "<li id='$row->term_id' class='lineitem'><input type='checkbox'".$check." name='navCats[]' value='$row->term_id' />$row->name</li>";
		}?>
	</ul>

	<input type="button" id="orderButton" Value="<?php _e('Click to Order Categories','mycategoryorder'); ?>" onclick="javascript:orderCats();">&nbsp;&nbsp;<strong id="updateText"></strong>
</div>
<div class="clear"></div>
<script language="JavaScript">
	
	function mycategoryrderaddloadevent(){
		jQuery("#orderCats").sortable({ 
			placeholder: "ui-selected", 
			revert: false,
			tolerance: "pointer" 
		});
	};
 

		
 
		
	addLoadEvent(mycategoryrderaddloadevent);

	function orderCats() {
		var cats = [];
		jQuery('#orderCats input:checked').each(function() { cats.push(this.value); });	
		var catList = cats.join(",");
		
		jQuery("#orderButton").css("display", "none");
		jQuery("#updateText").html("<?php _e('Updating Category Order...','mycategoryorder'); ?>");
		
		idList = jQuery("#orderCats").sortable("toArray");
		location.href = '<?php echo mycategoryorder_getTarget(); ?>?page=swift-options&mode=act_OrderCategories&parentID=<?php echo $parentID; ?>&idString='+idList+'&catString='+catList+'#Header-Options';
	}
	function goEdit ()
	{
		if(jQuery("#cats").val() != "")
			location.href="<?php echo mycategoryorder_getTarget(); ?>?page=swift-options&parentID="+jQuery("#cats").val();
	}
</script>

<?php
} 

function swift_mycategoryorder_applyorderfilter($orderby, $args)
{
	if($args['orderby'] == 'order')
		return 't.term_order';
	else
		return $orderby;
}

add_filter('get_terms_orderby', 'swift_mycategoryorder_applyorderfilter', 10, 2);



?>