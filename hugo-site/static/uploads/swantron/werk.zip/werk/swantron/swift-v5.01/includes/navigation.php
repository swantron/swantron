<?php
function navigation($option,$position){
	switch ($option) {
    
	case 'none':break;
    
	case 'Pages': ?>
 
<div id="nav<?php echo $position;?>-container" class="clearfix">
	<div id="nav1" class="grid_960">
    <ul class="navigation top" id="dropmenu">
    	<?php if (is_page()) { $highlight = "page_item"; } else {$highlight = "page_item current_page_item"; } ?>
		<li class="<?php echo $highlight; ?> first"><a href="<?php bloginfo('url'); ?>">Home</a></li>
        <?php $query='&title_li=&include='.get_option('swift_page_inc'); wp_list_pages($query); ?>
        <?php if($links=get_option('swift_pagenav_links')) echo $links;?>
    </ul>
     <?php if($position==2&&get_option('swift_searchbox_disable')!="true") include (TEMPLATEPATH . '/searchform-nav.php');?>
     <?php if($position==1&&get_option('swift_rsslinks_disable')!="true") include (INCLUDES . '/rss-links.php');?>
	</div><!--/nav1-->
</div><!--/nav1-container-->

<?php    break;case 'Categories': ?>
 <div id="nav<?php echo $position;?>-container" class="clearfix">
	<div id="nav1" class="grid_960">
    <ul class="navigation bottom" id="dropmenu">
    	<?php if (is_page()) { $highlight = "page_item"; } else {$highlight = "page_item current_page_item"; } ?>
		<li class="<?php echo $highlight; ?> first"><a href="<?php bloginfo('url'); ?>">Home</a></li>
        <?php $query='&orderby=order&title_li=&include='.get_option('swift_cat_inc'); wp_list_categories($query); ?>
        <?php if($links=get_option('swift_catnav_links')) echo $links;?>
    </ul>  
    <?php if($position==2&&get_option('swift_searchbox_disable')!="true") include (TEMPLATEPATH . '/searchform-nav.php');?>
	</div><!--/nav1-->
</div><!--/nav1-container-->
        <?php break;
}
}
?>