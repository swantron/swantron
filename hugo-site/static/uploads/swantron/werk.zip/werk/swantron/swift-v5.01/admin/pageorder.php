<?php  
 

function swift_mypageorder()
{
global $wpdb;
$mode = "";
$mode = $_GET['mode'];
$parentID = 0;

if (isset($_GET['parentID']))
	$parentID = $_GET['parentID'];
	
if(isset($_GET['hideNote']))
	update_option('mypageorder_hideNote', '1');
	
$success = "";

if($mode == "act_OrderPages")
	$success = swift_mypageorder_updateOrder();
	$subPageStr = swift_mypageorder_getSubPages($parentID);

?>

<div id="page-order">
	<h2><?php _e('My Page Order', 'mypageorder') ?></h2>
	<?php 
	echo $success;

	?>
	<h3><?php _e('Order Pages', 'mypageorder') ?></h3>
	    <p>Start by selecting the pages you want to include in your nav menu. Next, drag and drop the pages to change their display order (topmost item displays first), click the order pages button below to save.</p>
	<ul id="order">
	<?php
	
	$inc=explode(',',get_option('swift_page_inc'));
	$results = mypageorder_pageQuery();
	foreach($results as $row)
	{
		if (in_array($row->ID, $inc))$check='"checked"'; 
		else  $check="";
	$output='<li id='.$row->ID.' class="lineitem"><input type="checkbox" name="navPages[]"'.$check.' value="'.$row->ID.'" />'.$row->post_title.'</li>';
	echo $output;	
	}
	?>
	</ul>
	
	<input type="button" id="orderButton" Value="<?php _e('Click to Order Pages', 'mypageorder') ?>" onclick="javascript:orderPages();">&nbsp;&nbsp;<strong id="updateText"></strong>
</div>



<script type="text/javascript">
// <![CDATA[

	function mypageorderaddloadevent(){
		jQuery("#order").sortable({ 
			placeholder: "ui-selected", 
			revert: false,
			tolerance: "pointer" 
		});
	};

	addLoadEvent(mypageorderaddloadevent);
	
	function orderPages() {
		jQuery("#orderButton").css("display", "none");
		jQuery("#updateText").html("<?php _e('Updating Page Order...', 'mypageorder') ?>");
		idList = jQuery("#order").sortable("toArray");
		
		var pages = [];
		jQuery('#order input:checked').each(function() { pages.push(this.value); });	
		var pagesList = pages.join(",");
	 
		
		location.href = '<?php echo swift_mypageorder_getTarget(); ?>?page=swift-options&mode=act_OrderPages&parentID=<?php echo $parentID; ?>&idString='+idList+'&pageString='+pagesList+'#Header-Options';
				 
	}


	function goEdit () {
		if(jQuery("#pages").val() != "")
			location.href="<?php echo swift_mypageorder_getTarget(); ?>?page=swift-options&mode=dsp_OrderPages&parentID="+jQuery("#pages").val();
	}
// ]]>
</script>
<?php
}

//Switch page target depending on version
function swift_mypageorder_getTarget() {
	return "admin.php";
}

function swift_mypageorder_updateOrder()
{
	global $wpdb;

	$idString = $_GET['idString'];
	$pageList =  $_GET['pageString'];

	$IDs = explode(",", $idString);
	$result = count($IDs);

	for($i = 0; $i < $result; $i++)
	{
		$wpdb->query("UPDATE $wpdb->posts SET menu_order = '$i' WHERE id ='$IDs[$i]'");
    }
	update_option( 'swift_page_inc', $pageList );
	return '<div id="message" class="updated fade"><p>'. __('Page order updated successfully.', 'mypageorder').'</p></div>';
}

function swift_mypageorder_getSubPages($parentID)
{
	global $wpdb;
	
	$subPageStr = "";
	$results = mypageorder_pageQuery($parentID);
	foreach($results as $row)
	{
		$postCount=$wpdb->get_row("SELECT count(*) as postsCount FROM $wpdb->posts WHERE post_parent = $row->ID and post_type = 'page' ", ARRAY_N);
		if($postCount[0] > 0)
	    	$subPageStr = $subPageStr."<option value='$row->ID'>$row->post_title</option>";
	}
	return $subPageStr;
}

function mypageorder_pageQuery()
{
	global $wpdb;
	
	return $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type = 'page' ORDER BY menu_order ASC");
}

function mypageorder_getParentLink($parentID)
{
	global $wpdb;
	
	if($parentID != 0)
	{
		$parentsParent = $wpdb->get_row("SELECT post_parent FROM $wpdb->posts WHERE ID = $parentID ", ARRAY_N);
		return "<a href='". swift_mypageorder_getTarget() . "?page=mypageorder&parentID=$parentsParent[0]'>" . __('Return to parent page', 'mypageorder') . "</a>";
	}
	
	return "";
}

?>