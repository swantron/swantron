<?php 
//Access the WordPress Categories via an Array
$swift_categories = array();  
$swift_categories_obj = get_categories('hide_empty=0');
foreach ($swift_categories_obj as $swift_cat) 
{$swift_categories[$swift_cat->cat_ID] = $swift_cat->cat_name;}
$categories_tmp = array_unshift($swift_categories, "Show recent posts");   
       
//Access the WordPress Pages via an Array
$swift_pages = array();
$swift_pages_obj = get_pages('sort_column=post_parent,menu_order');    
foreach ($swift_pages_obj as $swift_page) 
{$swift_pages[$swift_page->ID] = $swift_page->post_name; }
$swift_pages_tmp = array_unshift($swift_pages, "Select a page:");  


$themename = "Swift";
$shortname = "swift";
$GLOBALS['template_path'] = get_bloginfo('template_directory');
global $themename, $shortname, $swift_options;
////////////////////////
$swift_options[] = array(); 
$swift_options[] =array("type" => "open-options-div");

$swift_options[] = array( "name" => "General-Settings",
                    "type" => "heading");


$swift_options[] = array( "name" => "Custom Favicon",
					"desc" => "Enter the URL of a 16px x 16px Png/Gif image that will represent your website's favicon.",
					"id" => $shortname."_favicon",
					"std" => "",
					"type" => "text"); 

$swift_options[] = array( "name" => "Header Scripts",
					"desc" => "If you need to add scripts to your header (like Mint tracking code, perhaps), you should enter them in the box below.",
					"id" => $shortname."_header_scripts",
					"std" => "",
					"type" => "textarea"); 

$swift_options[] = array( "name" => "Footer Scripts",
					"desc" => "Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme.",
					"id" => $shortname."_footer_scripts",
					"std" => "",
					"type" => "textarea"); 


$swift_options[] = array(	"name" => "Feedburner ID",
						"desc" => "Enter your Feedburner ID here.",
			    		"id" => $shortname."_feedburner_id",
			    		"std" => "",
			    		"type" => "text");	

$swift_options[] =array("type" => "close");

//Header Options Start

$swift_options[] = array( "name" => "Header-Options",
                    "type" => "heading");

$swift_options[] = array( "name" => "Custom Logo",
					"desc" => "Enter the URL of your logo (http://yoursite.com/logo.png)",
					"id" => $shortname."_logo",
					"std" => "",
					"type" => "text");    


$swift_options[] = array( "name" => "Top Navigation Options",
					"desc" => "Select what you want to display in top navigation, select none if you dont want to have navigation links above logo/sitename.",
					"id" => $shortname."_nav1",
					"std" => "Pages",
					"type" => "radio",
					"options" => array('None','Pages','Categories'));

$swift_options[] = array( "name" => "Bottom Navigation Options",
					"desc" => "Select what you want to display in top navigation, select none if you dont want to have navigation links below logo/sitename.",
					"id" => $shortname."_nav2",
					"std" => "Categories",
					"type" => "radio",
					"options" => array('None','Pages','Categories'));

$swift_options[] = array(    "name" => "Append Links to the PAGE navigation in header",
        "desc" => 'Add your links in the following format &lt;li&gt;&lt; a href="http://yourURL.com"&gt; SwiftThems&lt;/a&gt;&lt;/li&gt;',
        "id" => $shortname."_pagenav_links",
        "type" => "textarea");

$swift_options[] = array(    "name" => "Append Links to the CATEGORY navigation in header",
        "desc" => 'Add your links in the following format &lt;li&gt;&lt; a href="http://yourURL.com"&gt; SwiftThems&lt;/a&gt;&lt;/li&gt;',
        "id" => $shortname."_catnav_links",
        "type" => "textarea");

$swift_options[] = array(  "name" => "Disable RSS links",
        			"desc" => "Check this box if you don't want to display RSS links in the navigation above logo/sitename.",
        			"id" => $shortname."_rsslinks_disable",
        			"type" => "checkbox",
        			"std" => "false");

$swift_options[] = array(  "name" => "Disable Search Box",
        			"desc" => "Check this box if you don't want to display search box in the navigation below logo/sitename.",
        			"id" => $shortname."_searchbox_disable",
        			"type" => "checkbox",
        			"std" => "false"); 
 
$swift_options[] =array("type" => "ordering");
$swift_options[] =array("type" => "close");

//Home Page Options
$swift_options[] = array( "name" => "Homepage",
                    "type" => "heading");

$swift_options[] = array(  "name" => "Disable thumbnails on homepage",
        "desc" => "Check this box if you would like to DISABLE thumbnails on homepage.",
        "id" => $shortname."_thumbs_disable",
        "type" => "checkbox",
        "std" => "false");

$swift_options[] = array(  "name" => "Display excerpts on homepage",
        "desc" => "<b>Excerpt</b> is summary or description of a post",
        "id" => $shortname."_excerpts_enable",
        "type" => "checkbox",
        "std" => "false");

$swift_options[] = array(  "name" => "Display excerpts on archives",
        "desc" => "<b>Excerpt</b> is summary or description of a post",
        "id" => $shortname."_archive_excerpts_enable",
        "type" => "checkbox",
        "std" => "false");

$swift_options[] = array( "name" => "Show Full Content",
					"desc" => "If you are displaying excerpts on home page, then select the number of full length posts to be displayed on home page.",
					"id" => $shortname."_full_posts_number",
					"std" => "2",
					"type" => "select",
					"options" => array(0,1,2,3,4,5));

$swift_options[] = array(  "name" => "ENABLE popular posts on homepage",
        "desc" => "Check this box if you would like to ENABLE popular posts on homepage.<b>Note</b>: This feature doesn't work in magazine layout.",
        "id" => $shortname."_popular_enable",
        "type" => "checkbox",
        "std" => "false");

$swift_options[] = array( "name" => "Number of Popular posts",
					"desc" => "Select the number of popular posts you want to display on the home page.",
					"id" => $shortname."_popular_posts_number",
					"std" => "6",
					"type" => "select",
					"options" => array(1,2,3,4,5,6,7,8,9,10));

$swift_options[] = array(  "name" => "Disable Featured post slider",
        "desc" => "Check this box if you would like to DISABLE featured posts slider.",
        "id" => $shortname."_featured_disable",
        "type" => "checkbox",
        "std" => "false");

$swift_options[] = array( "name" => "Featured Category",
					"desc" => "Select the category that you would like to have displayed in the featured section on your homepage.",
					"id" => $shortname."_featured_category",
					"std" => "Show recent posts",
					"type" => "select",
					"options" => $swift_categories);

$swift_options[] = array( "name" => "Number of Featured Posts",
					"desc" => "Select the number of posts to be displayed in slider",
					"id" => $shortname."_featured_posts_number",
					"std" => 3,
					"type" => "select",
					"options" => array(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20));
$swift_options[] = array(  "name" => "Disable thumbnails in slider",
        "desc" => "Check this box if you would like to DISABLE thumbnails in slider.",
        "id" => $shortname."_thumbs_slider_disable",
        "type" => "checkbox",
        "std" => "false");

$swift_options[] =array("type" => "close");

//Single Page

$swift_options[] = array( "name" => "SinglePage",
                    "type" => "heading");

$swift_options[] = array(  "name" => "Display subscribe via EMail box",
        "desc" => "Check this box, if you would like to display EMail Subscription box. You have to enter your feedburner ID in general settings for this to work",
        "id" => $shortname."_email_subscription_enable",
        "type" => "checkbox",
        "std" => "true");

$swift_options[] = array(  "name" => "Display Social Bookmarking Icons",
        "desc" => "Check this box, if you would like to display social bookmarking Icons at the end of the post.",
        "id" => $shortname."_socialmedia_enable",
        "type" => "checkbox",
        "std" => "true");

$swift_options[] = array(  "name" => "Display Author Info",
        "desc" => "Check this box, if you would like to display author bio at the end of the post.",
        "id" => $shortname."_author_info_enable",
        "type" => "checkbox",
        "std" => "true");

$swift_options[] =array("type" => "close");
//Ad Management

$swift_options[] = array( "name" => "Ad-Management",
                    "type" => "heading");
$swift_options[] = array(  "name" => "Enable header Ad",
        "desc" => "",
        "id" => $shortname."_header_ad_enable",
        "type" => "checkbox",
        "std" => "false");
$swift_options[] = array(    "name" => "Ad Code",
        "desc" => "Enter your ad code here, preferably 468*60 ad",
        "id" => $shortname."_header_adcode",
        "type" => "textarea");

$swift_options[] = array(  "name" => "Enable ads below the navigation bar",
        "desc" => "",
        "id" => $shortname."_nav_adsense_enable",
        "type" => "checkbox",
        "std" => "false");
$swift_options[] = array(    "name" => "Ad Code",
        "desc" => "Enter your ad code here, preferably 728*15 list unit or 728*90 lead board ad",
        "id" => $shortname."_nav_adcode",
        "type" => "textarea");

$swift_options[] = array(  "name" => "Enable ad's below title on single post page",
        "desc" => "",
        "id" => $shortname."_adsense_enable",
        "type" => "checkbox",
        "std" => "false");
$swift_options[] = array(    "name" => "Ad Code",
        "desc" => "Enter your ad code here",
        "id" => $shortname."_adcode",
        "type" => "textarea");

$swift_options[] = array(  "name" => "Disable ad's after post content on single post page",
        "desc" => "Check this box if you would like to ENABLE the ads after post content on single post page.",
        "id" => $shortname."_adsense_afterpost_enable",
        "type" => "checkbox",
        "std" => "false");
$swift_options[] = array(    "name" => "Ad Code",
        "desc" => "Enter your ad code here",
        "id" => $shortname."_adsense_afterpost",
        "type" => "textarea");


$swift_options[] = array(    "name" => "Banner-1",
        "desc" => "Enter your image url here",
        "id" => $shortname."_banner1image",
        "type" => "text");
$swift_options[] = array(    "name" => "Banner destination",
        "desc" => "Enter destination url here",
        "id" => $shortname."_banner1destination",
        "type" => "text");
$swift_options[] = array(    "name" => "Banner-2",
        "desc" => "Enter your image url here",
        "id" => $shortname."_banner2image",
        "type" => "text");
$swift_options[] = array(    "name" => "Banner destination",
        "desc" => "Enter destination url here",
        "id" => $shortname."_banner2destination",
        "type" => "text");

$swift_options[] = array(    "name" => "Banner-3",
        "desc" => "Enter your image url here",
        "id" => $shortname."_banner3image",
        "type" => "text");
$swift_options[] = array(    "name" => "Banner destination",
        "desc" => "Enter destination url here",
        "id" => $shortname."_banner3destination",
        "type" => "text");

$swift_options[] = array(    "name" => "Banner-4",
        "desc" => "Enter your image url here",
        "id" => $shortname."_banner4image",
        "type" => "text");
$swift_options[] = array(    "name" => "Banner destination",
        "desc" => "Enter destination url here",
        "id" => $shortname."_banner4destination",
        "type" => "text");
$swift_options[] =array("type" => "clear");
$swift_options[] =array("type" => "close");





$swift_options[] = array( "name" => "",
					"desc" => "this is a random variable just to know that the options have been changed, it wont be displayed any where",
					"id" => $shortname."_random",
					"std" => "FFF",
					"type" => "hidden");



                    
?>