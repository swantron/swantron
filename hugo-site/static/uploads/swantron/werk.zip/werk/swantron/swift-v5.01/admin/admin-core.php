<?php
add_action('admin_menu', 'swift_headers1');
add_action('admin_head', 'swift_headers2');
?>
<?php
function swift_headers1(){
	if ( $_GET['page'] == "swift-options"||$_GET['page'] == "swift-color-cptions" ){
		wp_enqueue_script( 'jquery' ); 
		wp_enqueue_script('jquery-ui-core');
		wp_enqueue_script('jquery-ui-tabs');
		wp_enqueue_script('jquery-ui-sortable');
	}
}
?>
<?php 
function swift_headers2(){ 
if ( $_GET['page'] == "swift-options"||$_GET['page'] == "swift-color-cptions" ){
?>
<script type="text/javascript">
	jQuery(function() {
	jQuery(".tabmenu").removeClass("hidden");
	jQuery(".tabs h2").addClass("hidden");
	jQuery(".tabs").tabs();
	});
</script> 
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url')?>/admin/admin-styles.css" media="screen" />	
<?php }
if ($_GET['page'] == "swift-color-cptions" ){?>
	<script language="javascript" type="text/javascript" src="<?php bloginfo('template_url')?>/admin/jscolor/jscolor.js"></script> 
<?php } ?>
<?php } ?>
<?php
add_action('admin_menu', 'swift_themes_menu');

function swift_themes_menu() {
add_menu_page('Swift Theme Options', 'Swift Options', 'administrator', 'swift-options', 'swiftOptions','http://swiftthemes.com/blog/wp-content/themes/swift-v4.1.5/images/favicon.ico',62);
add_submenu_page( 'swift-options', 'Design Options', 'Design Options', 'administrator', 'swift-color-cptions', 'swiftColorOptions');
}

function swiftOptions() {
 include(ADMIN.'/swift-options.php');
}
function swiftColorOptions() {
 include(ADMIN.'/swift-color-options.php');
}

function resetSwiftOptions(){
	if( 'Reset' == $_POST['general-reset'] || 'Reset' == $_POST['design-reset'] ) {
	global $swift_design_options;
	global $swift_options;
	if('Reset' == $_POST['general-reset']) $options=$swift_options;
	else  $options=$swift_design_options;
            foreach ($options as $value) {
 				delete_option($value['id']);
				update_option($value['id'],$value['std']);	 
				}
				create_style_sheet();
			}
}

function first_run_options() {

  if ( get_option('swift_activation_check')!="set" ) {
    // DO INITIALISATION STUFF
	$uploads_path=get_option( 'upload_path' );

	$filename = $uploads_path.'/swift_default.jpg';
		if (!file_exists($filename)):
			$file = TEMPLATEPATH.'/images/default.jpg';
			$newfile = $filename;
			copy($file, $newfile);
		endif;
    // Add marker so it doesn't run in future
    update_option('swift_activation_check', "set");
  }
}

function delete_stuff() {
  delete_option('swift_activation_check');
} 
?>
