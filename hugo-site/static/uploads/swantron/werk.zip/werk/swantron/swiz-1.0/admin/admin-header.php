<?php function admin_header(){?>


<div class="swiz-wrapper" class="wrap clearfix">


<div id="swiz-header" class="clearfix">

	<div id="swiz-logo" class="alignleft">
	<a href="http://swantron.com" rel="external" ><img src="<?php bloginfo('template_url')?>/admin/images/swiz-logo.png" /></a>
	</div>

    
</div>	
    
	<div id="nav">
    	<ul style="float:left;border-bottom:none">
        <li style="padding:.2em 1em; border:none" >You are using v5.0</li>
        </ul>
    	<ul class="clearfix">
    		<li><a href="http://26outs.com" title="baseball wonderfulness">26outs</a></li>
			<li><a href="http://swantron.com" title="robots">swantron</a></li>
    	</ul>
	</div><!--/nav1-->
<div class="clear"></div>
<?php }?>
