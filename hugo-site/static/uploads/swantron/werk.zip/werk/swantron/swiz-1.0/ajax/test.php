<?php
/*
Template Name: test
*/
?>
<?php bloginfo('name'); ?>-----